package com.ghanima.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int green = Color.rgb(6, 78, 59);
    private final int emerald = Color.rgb(10, 118, 85);
    private final int gold = Color.rgb(255, 204, 64);
    private final int cream = Color.rgb(247, 249, 245);
    private int points = 0;
    private LinearLayout root, content, header;
    private TextView pointsView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(10, 8, 10, 8);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private void init(String title) {
        root = column();
        root.setBackgroundColor(cream);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        header = row();
        header.setPadding(14, 18, 14, 18);
        header.setBackgroundColor(green);
        TextView logo = text("🎁 غنيمة", 23, Color.WHITE, true);
        header.addView(logo, new LinearLayout.LayoutParams(0, -2, 1));
        pointsView = text("🪙 " + points + " نقطة", 15, gold, true);
        header.addView(pointsView);
        root.addView(header);
        ScrollView scroll = new ScrollView(this);
        content = column();
        content.setPadding(16, 14, 16, 24);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout nav = row();
        nav.setBackgroundColor(Color.WHITE);
        addNav(nav, "الرئيسية", this::showHome);
        addNav(nav, "المكافآت", this::showRewards);
        addNav(nav, "رصيدي", this::showBalance);
        root.addView(nav);
        setContentView(root);
    }

    private void addNav(LinearLayout nav, String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(12); b.setTextColor(green);
        b.setBackgroundColor(Color.WHITE);
        b.setOnClickListener(v -> action.run());
        nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private void card(LinearLayout parent, String title, String detail, String button, Runnable action) {
        LinearLayout c = column();
        c.setPadding(12, 12, 12, 12);
        c.setBackground(bg(Color.WHITE, 22));
        TextView h = text(title, 18, green, true);
        h.setGravity(Gravity.RIGHT);
        c.addView(h);
        TextView d = text(detail, 14, Color.DKGRAY, false);
        d.setGravity(Gravity.RIGHT);
        c.addView(d);
        if (button != null) {
            Button b = new Button(this);
            b.setText(button); b.setTextColor(Color.WHITE); b.setBackground(bg(emerald, 18));
            b.setOnClickListener(v -> action.run());
            c.addView(b);
        }
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 8, 0, 8);
        parent.addView(c, p);
    }

    private void showHome() {
        init("الرئيسية");
        content.addView(text("أهلًا بك في غنيمة 👋", 24, green, true));
        content.addView(text("شاهد الإعلانات التجريبية واجمع النقاط", 15, Color.DKGRAY, false));
        card(content, "🍔 عرض وجبة", "إعلان تجريبي — 20 ثانية\nالمكافأة التجريبية: 10 نقاط", "شاهد الإعلان التجريبي", () ->
            new AlertDialog.Builder(this).setTitle("إعلان تجريبي")
                .setMessage("هذه محاكاة للاختبار فقط وليست مشاهدة إعلان مدفوعًا. اضغط متابعة لإكمال التجربة والحصول على 10 نقاط تجريبية.")
                .setNegativeButton("إلغاء", (d,w) -> {})
                .setPositiveButton("إكمال التجربة", (d,w) -> {
                    points += 10;
                    showHome();
                    Toast.makeText(this, "أُضيفت 10 نقاط تجريبية", Toast.LENGTH_SHORT).show();
                }).show());
        card(content, "☕ عرض قهوة", "إعلان تجريبي — 15 ثانية\nالمكافأة التجريبية: 5 نقاط", "جرّب الإعلان", () -> {
            points += 5; showHome();
            Toast.makeText(this, "أُضيفت 5 نقاط تجريبية", Toast.LENGTH_SHORT).show();
        });
        card(content, "كيف يعمل غنيمة؟", "1. شاهد إعلانًا مؤهلًا.\n2. اجمع النقاط.\n3. استبدل النقاط بمكافآت متاحة.", null, null);
        content.addView(text("تنبيه: النقاط في هذه النسخة تجريبية ولا قيمة نقدية لها.", 12, Color.GRAY, false));
    }

    private void showRewards() {
        init("المكافآت");
        content.addView(text("متجر المكافآت 🎁", 23, green, true));
        card(content, "🍔 قسيمة وجبة", "السعر التجريبي: 500 نقطة\nغير متاحة للاستبدال الفعلي في النسخة التجريبية.", "تجربة الاستبدال", () -> redeem(500, "قسيمة وجبة"));
        card(content, "☕ قسيمة قهوة", "السعر التجريبي: 150 نقطة\nغير متاحة للاستبدال الفعلي في النسخة التجريبية.", "تجربة الاستبدال", () -> redeem(150, "قسيمة قهوة"));
        card(content, "🛍️ قسيمة متجر", "السعر التجريبي: 800 نقطة\nتحتاج إلى شريك تجاري لتفعيلها.", "تجربة الاستبدال", () -> redeem(800, "قسيمة متجر"));
    }

    private void redeem(int cost, String name) {
        if (points < cost) {
            new AlertDialog.Builder(this).setTitle("نقاط غير كافية")
                .setMessage("تحتاج إلى " + cost + " نقطة. رصيدك الحالي " + points + " نقطة. المكافآت هنا تجريبية فقط.")
                .setPositiveButton("حسنًا", null).show();
        } else {
            new AlertDialog.Builder(this).setTitle("نسخة تجريبية")
                .setMessage("لا يمكن استبدال " + name + " فعليًا حتى يتم ربط التطبيق بمكافآت حقيقية.")
                .setPositiveButton("حسنًا", null).show();
        }
    }

    private void showBalance() {
        init("رصيدي");
        content.addView(text("محفظة النقاط", 24, green, true));
        TextView total = text("🪙 " + points + " نقطة", 28, green, true);
        total.setBackground(bg(Color.WHITE, 24));
        content.addView(total);
        card(content, "سجل النقاط", "هذه نسخة تجريبية؛ الرصيد محفوظ خلال جلسة التشغيل الحالية فقط.", null, null);
        card(content, "الخطوة التالية", "في النسخة الكاملة سنضيف حسابات المستخدمين وقاعدة بيانات آمنة وسجلًا دائمًا للنقاط.", null, null);
        Button reset = new Button(this);
        reset.setText("إعادة تعيين النقاط التجريبية");
        reset.setOnClickListener(v -> { points = 0; showBalance(); });
        content.addView(reset);
    }
}
